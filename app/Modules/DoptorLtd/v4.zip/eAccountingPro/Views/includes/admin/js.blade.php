<!-- BEGIN PAGE LEVEL PLUGINS -->
{{-- {!! HTML::script("/../app/Modules/DoptorLtd/eAccountingPro/assets/js/jquery1.12.min.js") !!} --}}
{!! HTML::script("/app/Modules/DoptorLtd/eAccountingPro/assets/js/custom.js") !!}
{!! HTML::script("/app/Modules/DoptorLtd/eAccountingPro/assets/js/material.min.js") !!}
{!! HTML::script("/app/Modules/DoptorLtd/eAccountingPro/assets/js/material-kit.js") !!}
{!! HTML::script("/app/Modules/DoptorLtd/eAccountingPro/assets/js/nouislider.min.js") !!}
{!! HTML::script("assets/backend/default/plugins/data-tables/jquery.dataTables.js") !!}
{!! HTML::script("assets/backend/default/plugins/data-tables/DT_bootstrap.js") !!}
<!-- END PAGE LEVEL PLUGINS -->

