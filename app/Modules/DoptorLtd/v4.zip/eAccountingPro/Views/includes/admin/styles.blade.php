<!-- BEGIN PAGE LEVEL STYLES -->
{!! HTML::style('app/Modules/DoptorLtd/HumanResourcePro/assets/css/font-awesome.min.css') !!}
{{-- {!! HTML::style('app/Modules/DoptorLtd/HumanResourcePro/assets/css/material-kit.css') !!}   --}}
<!-- {!! HTML::style('../app/Modules/DoptorLtd/HumanResourcePro/assets/css/bootstrap-theme-material.min.css') !!}  -->
{!! HTML::style('app/Modules/DoptorLtd/HumanResourcePro/assets/css/custom.css') !!} 
{!! HTML::style('/app/Modules/DoptorLtd/HumanResourcePro/assets/css/bootstrap-theme-flat.min.css') !!}  
{{-- {!! HTML::style('/../app/Modules/DoptorLtd/HumanResourcePro/assets/css/bootstrap-theme.css') !!}
{!! HTML::style('/../app/Modules/DoptorLtd/HumanResourcePro/assets/css/bootstrap-theme.min.css') !!} --}}
<!-- END PAGE LEVEL STYLES -->

